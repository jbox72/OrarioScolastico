namespace OrarioClasse.Engine;
public sealed record EsitoScambio(bool Autorizzato, string Messaggio);
