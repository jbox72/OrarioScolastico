namespace OrarioClasse.Model;

public sealed record Tessera(string Materia, string Aula);
